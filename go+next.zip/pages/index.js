<style>
  /* 添加美化计算器 UI 的 CSS 样式 */
  .calculator {
    width: 300px;
    margin: 0 auto;
    border: 1px solid #ccc;
    border-radius: 5px;
    padding: 10px;
    background-color: #f9f9f9;
  }
  .calculator input[type="text"] {
    width: 100%;
    height: 40px;
    margin-bottom: 10px;
    font-size: 20px;
    text-align: right;
  }
  .calculator .buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 5px;
  }
  .calculator .buttons button {
    width: 100%;
    height: 40px;
    font-size: 18px;
  }
</style>